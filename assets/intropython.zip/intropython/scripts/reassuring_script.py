print "You're doing well so far!"
