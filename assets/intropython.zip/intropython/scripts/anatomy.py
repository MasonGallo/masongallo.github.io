# This is an introduction to tell you the main idea of the script
"""
This script is meant to demonstrate the basic building blocks of a Python
script. Comments will describe each section, such as above. The main goal of
the script is to greet the user based on a name given on the command line.
"""

# we first import the packages we need to use
import sys


# we create the main function that we want our script to do
def main():
	# notice the indent
	"""
	Greets the user using the first word given from the command line. Returns a
	fallback in case the user doesn't provide anything on the command line.
	"""

	# We check if at least 2 arguments are given on the command line:
	# the script itself, and hopefully a name given by the user
	if len(sys.argv) >= 2:
		# sys.argv gives us all that was typed on the command line as a string
		# the first element (0th) is always the name of the script itself
		# the second element is the first thing we write after, and so on...
		name = sys.argv[1]
		# return statement makes sure our function has a result!
		# notice we use a + to print 2 strings
		return 'Nice to meet you, ' + name
	else:
		return 'You did not tell me your name :('

# these 2 lines of code tell the machine what to do when we call the script
# directly from the command line
if __name__ == '__main__':
	print main()

# to use this script, call it directly from the terminal with: 
# python script_name.py name
# Example below:
# python anatomy.py mason
# returns:
# Nice to meet you, mason
# What happens if we write:
# python anatomy.py