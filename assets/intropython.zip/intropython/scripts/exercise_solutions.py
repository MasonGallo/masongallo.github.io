#!/usr/bin/env python
"""
EXERCISE
In this exercise, you'll import the hello_goodbye script and use both the 
hello() and bye() methods from the script you imported. 

Remember, to execute this script type `python exercise.py` on the command line
"""

# your code here
import hello_goodbye

hello_goodbye.hello()

print("Mason, I...")

hello_goodbye.bye()